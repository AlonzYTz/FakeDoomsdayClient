# Fake Doomsday Client - Phone Build

Minecraft: Java Edition 1.21.11
Fabric client mod

This project is a visual-only/cosmetic client-style GUI. The listed fake modules do not implement gameplay automation, combat, movement, packet manipulation, or other cheats.

## Build on a phone with GitHub Actions
1. Create a GitHub repository.
2. Upload the entire contents of this folder, including .github and gradlew.
3. Open the repository's Actions tab.
4. Choose "Build Fake Doomsday Client".
5. Tap "Run workflow".
6. Open the completed workflow run.
7. Download the "fake-doomsday-client" artifact.
8. The artifact contains the built JAR from build/libs/.

## Local build
Linux/Android terminal:
    ./gradlew build

Windows:
    gradlew.bat build

The bootstrap wrapper downloads Gradle 9.2.0 if Gradle is not already installed.
